# Crafter UI Extractor

Turn selected React components from your project into an installable shadcn registry. Runs locally; no source upload or project script execution. Requires Bun.

## Start

Unzip this folder and open a terminal here:

```sh
bun install
bun run extract --project ../my-app --entry src/components/card.tsx
```

The first command installs the TypeScript parser. The second prints the file graph, package dependencies, and any unresolved requirements. It does not modify your project.

When the graph resolves:

```sh
bun run extract --project ../my-app --entry src/components/card.tsx --out ../my-library
```

Choose an empty output directory. Repeat --entry to include more components. Use --name, --slug, and --homepage to customize the registry. Run --help for all options.

## Install the result

The generated README contains the exact shadcn install command and import paths. Install it into a separate app and verify its behavior before publishing.

## Supported

- TS/JS imports, re-exports, literal dynamic imports, type imports, and tsconfig aliases.
- Local JSON and imported SVG source.
- Declared package dependencies with registry versions.

## Review required

Stylesheets, binary assets, computed imports, undeclared packages, environment variables, and server-only code produce explicit issues instead of incomplete bundles. The extractor does not migrate global styles, provider setup, or infer a source license. A resolved graph proves file completeness, not matching visual behavior.
