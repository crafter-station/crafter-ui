# Crafter UI

Your components and defaults, built on shadcn and Base UI.

## Use in an app

Requires React 19, Tailwind CSS 4, and shadcn configured with the Base UI base. Start a clean app with:

```sh
bunx --bun shadcn@4.21.0 init --template next --base base --preset nova --name my-app
```

From that app, install the downloaded starter by its absolute local path:

```sh
bunx --bun shadcn@4.21.0 add /absolute/path/to/crafter-registry/public/r/starter.json
```

The starter applies your library theme and includes component source and its dependency closure. Installing an individual component preserves the existing app theme; install r/theme.json separately to apply your library defaults. Review existing-file conflicts before accepting replacements. This bundle supplies Base UI primitives; do not install it over an existing Radix component set without reviewing migration.

## Host your registry

Deploy this folder to Vercel (Other framework, output directory public) or serve public/ with any static host. The JSON is already built. Update library.json and registry.json if your public URL changes. Once available at https://ui.crafter.run:

```sh
bunx --bun shadcn@4.21.0 add https://ui.crafter.run/r/starter.json
```

You can also install individual items:

- https://ui.crafter.run/r/action-button.json
- https://ui.crafter.run/r/copy-button.json
- https://ui.crafter.run/r/text-field.json
- https://ui.crafter.run/r/empty-state.json
- https://ui.crafter.run/r/section-heading.json
- https://ui.crafter.run/r/settings-card.json

## Customize

Edit the source in components/ui/, then run `bun run build`. Add new entries to registry.json. The builder generated this initial catalog and all payloads from one definition. Your exported copy is yours to maintain.

## Usage

### Action button

Import from `@/components/ui/action-button`.

```tsx
<ActionButton pending={saving} pendingLabel="Saving…">Save changes</ActionButton>
```

### Copy button

Import from `@/components/ui/copy-button`.

```tsx
<CopyButton value="bun run dev" />
```

### Text field

Import from `@/components/ui/text-field`.

```tsx
<TextField label="Project name" description="Visible to your team" required />
```

### Empty state

Import from `@/components/ui/empty-state`.

```tsx
<EmptyState title="No projects yet" description="Create your first project." action={<Button>Create project</Button>} />
```

### Section heading

Import from `@/components/ui/section-heading`.

```tsx
<SectionHeading title="Projects" description="Everything you are building." />
```

### Settings card

Import from `@/components/ui/settings-card`.

```tsx
<SettingsCard name="My project" onSave={saveProject} />
```

See NOTICE.md for upstream attribution.
